package aicu.application.mps.voice.international.web.revenue;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.net.ftp.FTPClient;

import aicu.misc.widget.FtpManager;


@SuppressWarnings("unchecked")
public class FtpBBSUtil extends FtpManager {
	private static FtpBBSUtil ftpBBS ;
	private boolean connected = false;
	
	private FtpBBSUtil(){
		
	}

	public static FtpBBSUtil getFtpBBS() {
		if (ftpBBS == null) {
			ftpBBS =new FtpBBSUtil();
		}
		return ftpBBS;
	}
	
	public void FtpSento(String localPath, String host, String user,
			String pass, String path) throws Exception {
		/*
		 * @author:zhongfs @Date:2017-12-05 这个方法是用来把本地服务器的路径下的文件上传到ftp服务器上的路径
		 * 
		 */
		login(host, 21, user, pass);
		File parentFile = new File(localPath);
		File[] files = parentFile.listFiles();
		String outPath = path;
		for (File aFile : files) {
			if (aFile != null && aFile.getName() != null) {
				put(aFile, outPath, new String((aFile.getName())
						.getBytes("GB18030"), "ISO8859-1"));
			}
		}
		logout();
	}	
	
	public String checkPath(String path) {
		if (!path.startsWith("/"))
			path = "/" + path;
		return path;
	}
	
	public void put(File file, String path, String fileName) {
		login();
		path = checkPath(path);
		if (!this.isDirectoryExist(path)) {
			this.makeDirectory(path);
		}
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(file);
			put(fis, path+fileName);
		} catch (Exception e) {
			System.out.print(e);
			throw new RuntimeException("上传文件[" + path + "]失败", e);
		} finally {
			if (null != fis)
				try {
					fis.close();
				} catch (IOException e) {
					throw new RuntimeException("关闭读写流异常", e);
				}
			
		}
				
	}
	
}
