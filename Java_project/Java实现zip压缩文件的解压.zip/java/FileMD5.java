package aicu.application.mps.voice.util.md5;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.security.MessageDigest;

public class FileMD5 {
	
	 char hexdigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8',
			'9', 'A', 'B', 'C', 'D', 'E', 'F' };

	public  String getMD5(File file) {
		Boolean bool = false;
		FileInputStream fis = null;
		String filename=file.getName();
		String[] newfilepath=filename.split("\\.");
		String filenameTemp = file.getParent()+file.separator+newfilepath[0]+ ".md5";
		
		File md5file = new File(filenameTemp);
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			fis = new FileInputStream(file);
			byte[] buffer = new byte[2048];
			int length = -1;
			long s = System.currentTimeMillis();
			while ((length = fis.read(buffer)) != -1) {
				md.update(buffer, 0, length);
			}
			byte[] b = md.digest();
			//��ɵ�MD5����
			String filecontent=byteToHexString(b);
			if (!md5file.exists()) {
				md5file.createNewFile();
				bool = true;
				System.out.println("success create file,the file is "
						+ md5file.getName());
				writeFileContent(filenameTemp, filecontent);
			}
			else {
				md5file.delete();
				System.out.println("success delete file,the file is "
						+ md5file.getName());
				md5file.createNewFile();
				bool = true;
				System.out.println("success create file,the file is "
						+ md5file.getName());
				writeFileContent(filenameTemp, filecontent);	
			}
			return byteToHexString(b);
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		} finally {
			try {
				fis.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
	private  String byteToHexString(byte[] tmp) {
		String s;
		char str[] = new char[16 * 2]; 
		int k = 0; 
		for (int i = 0; i < 16; i++) { 	
			byte byte0 = tmp[i];
			str[k++] = hexdigits[byte0 >>> 4 & 0xf];	
			str[k++] = hexdigits[byte0 & 0xf]; 
		}
		s = new String(str); 
		return s;
	}
	
	public  boolean writeFileContent(String filepath, String newstr)
			throws IOException {
		Boolean bool = false;
		//String filein = newstr + "\r\n";
		String filein = new String(newstr);
		String temp = "";

		FileInputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		FileOutputStream fos = null;
		PrintWriter pw = null;
		try {
			File file = new File(filepath);
			fis = new FileInputStream(file);
			isr = new InputStreamReader(fis);
			br = new BufferedReader(isr);
			StringBuffer buffer = new StringBuffer();
			// �ļ�ԭ������
			for (int i = 0; (temp = br.readLine()) != null; i++) {
				buffer.append(temp);
				// ������֮��ķָ�� �൱�ڡ�\n��
				buffer = buffer.append(System.getProperty("line.separator"));
			}
			buffer.append(filein);

			fos = new FileOutputStream(file);
			pw = new PrintWriter(fos);
			pw.write(buffer.toString().toCharArray());
			pw.flush();
			bool = true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			if (pw != null) {
				pw.close();
			}
			if (fos != null) {
				fos.close();
			}
			if (br != null) {
				br.close();
			}
			if (isr != null) {
				isr.close();
			}
			if (fis != null) {
				fis.close();
			}
		}
		return bool;
	}
	
	public static void main(String arg[]) {
		
		FileMD5 filemd5=new FileMD5();
		String filepath="D:\\appfile\\CMBFSDWAL01001A2017070001001.000";
		File testfile=new File(filepath);
		String md5str=filemd5.getMD5(testfile);
		System.out.println(md5str);		
	}
}