package aicu.application.mps.voice.widget;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.Expand;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipOutputStream;

/**
 * 压缩工具类
 * @author User
 *
 */
public class ZipUtil {
	
	/**目录list
	  * @param fileNamesList
	  * @param file
	  * @param dirPath
	  * @return
	 **/
	 @SuppressWarnings("unchecked")
		private static List iteratorDirectory(List<File> fileNamesList, File scrDir) {
			File[] subFiles = scrDir.listFiles();
			for (int i=0; i<subFiles.length ; i++) {
				if (!subFiles[i].isDirectory()) {
					fileNamesList.add(subFiles[i]);
				} else {
					iteratorDirectory(fileNamesList,subFiles[i]);
				}
			}
			return fileNamesList;
		}
		
		
		
	/**压缩成zip包
	  * @param srcPath 		根目录
	  * @param outFileName	输出文件全路径
	 **/
    @SuppressWarnings("unchecked")
	public static void makeZip(File srcPath, String outFileName){

		byte[] buf = new byte[10240];
		List<File> countFileList = new ArrayList();
		countFileList = iteratorDirectory(countFileList,srcPath);
			
		try {
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outFileName));
			Iterator it = countFileList.iterator();
			int i = 0;
			while(it.hasNext())
			{	
				File file = (File) it.next();
				String zipDir = file.getPath().substring(srcPath.getPath().length()+1,file.getPath().length());
				String filePathAndName = file.getPath();
					
				FileInputStream in = new FileInputStream(new String(filePathAndName.getBytes("iso8859-1")));
				out.putNextEntry(new ZipEntry(new String(zipDir.getBytes("iso8859-1"))));
				int len_;
				while ((len_ = in.read(buf)) > 0) {
					out.write(buf, 0, len_);
				}
				out.closeEntry();
				in.close();
				i++;
			}
			out.close();
			
		}catch (IOException e) {		 	
			e.printStackTrace();
		 	throw new RuntimeException("ZIP_ERROR",e);
		}
	}
		
	/**压缩成zip包
	  * @param srcPath 		根目录
	  * @param outFileName	输出文件全路径
	 **/
   @SuppressWarnings("unchecked")
	public static void makeZipNoEncoding(File srcPath, String outFileName){

		byte[] buf = new byte[10240];
		List<File> countFileList = new ArrayList();
		countFileList = iteratorDirectory(countFileList,srcPath);
			
		try {
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outFileName));
			out.setEncoding("gb18030");
			Iterator it = countFileList.iterator();
			int i = 0;
			while(it.hasNext())
			{	
				File file = (File) it.next();
				String zipDir = file.getPath().substring(srcPath.getPath().length()+1,file.getPath().length());
				String filePathAndName = file.getPath();
					
				FileInputStream in = new FileInputStream(filePathAndName);
				out.putNextEntry(new ZipEntry(zipDir));
				int len_;
				while ((len_ = in.read(buf)) > 0) {
					out.write(buf, 0, len_);
				}
				out.closeEntry();
				in.close();
				i++;
			}
			out.close();
			
		}catch (IOException e) {		 	
		 	throw new RuntimeException("ZIP_ERROR",e);
		}
	}
   
   public static boolean unzip(File zipfile,String destDir) throws Exception{    
       boolean bool=false;
	   try{    
           Project p = new Project();    
           Expand e = new Expand();    
           e.setProject(p);    
           e.setSrc(zipfile);    
           e.setOverwrite(false);    
           e.setDest(new File(destDir));    
           e.setEncoding("gbk");    
           e.execute();  
           bool=true;
           return bool;
       }catch(Exception e){    
           throw e;  
       }    
   }     
}
