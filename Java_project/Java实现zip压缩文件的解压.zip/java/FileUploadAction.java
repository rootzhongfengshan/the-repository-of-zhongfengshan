package aicu.application.mps.voice.international.web.revenue;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.commons.io.FileUtils;
import org.apache.struts2.interceptor.ParameterAware;
import aicu.application.mps.voice.global.VoiceConstant;
import aicu.application.mps.voice.global.web.BaseAction;
import aicu.application.mps.voice.global.web.QueryActionOnJmesa;
import aicu.application.mps.voice.util.md5.FileMD5;
import aicu.application.mps.voice.international.web.revenue.FtpBBSUtil;
import aicu.misc.util.query.QueryManager;
import aicu.misc.util.query.querymanager.QueryManagerOnIbatis;
import aicu.misc.util.dataquery.EasyDataFatcherOnIbatis;
import aicu.application.mps.voice.widget.ZipUtil;

/**
 * @author bilei
 * 上传调度action   访问此action的url规则为    moduleName_UPLOAD_serviceID.do  如  system_UPLOAD_ngnBillUpload.do
 */
public class FileUploadAction extends BaseAction {
	protected File upload;// 实际上传文件
	protected String uploadContentType; // 文件的内容类型
	protected String uploadFileName; // 上传文件名
	protected String uploadServiceId;//上传服务ID
	protected int OperationType;
	protected Map parameterMap;
	protected String rpmonth;

	public Map getParameterMap() {
		return parameterMap;
	}

	public void setParameterMap(Map parameterMap) {
		this.parameterMap = parameterMap;
	}

	public int getOperationType() {
		return OperationType;
	}

	public void setOperationType(int operationType) {
		OperationType = operationType;
	}

	public File getUpload() {
		return upload;
	}

	public void setUpload(File upload) {
		this.upload = upload;
	}

	public String getUploadContentType() {
		return uploadContentType;
	}

	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}

	public String getUploadFileName() {
		return uploadFileName;
	}

	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}

	public String getUploadServiceId() {
		return uploadServiceId;
	}

	public void setUploadServiceId(String uploadServiceId) {
		this.uploadServiceId = uploadServiceId;
	}

	/**
	 * 上传服务
	 * @return
	 * @throws Exception 
	 */
	public String smartUpload() throws Exception {
		if (upload == null || uploadFileName == null || uploadServiceId == null) {
			getResponse().setContentType("text/html;charset=utf-8");
			getResponse().getWriter().write(
					"<script>alert('你啥也没传上去，请再试试吧！');</script>");
			getResponse().getWriter().flush();
			return SUCCESS;
		}
		String datapath = getRealPath() + "upload" + File.separator
				+ UUID.randomUUID() + File.separator;
		File newFile = new File(new File(datapath), uploadFileName);
		
		if (!newFile.getParentFile().exists())
			newFile.getParentFile().mkdirs();
		FileUtils.copyFile(upload, newFile);
		
		FileMD5 filemd5 = new FileMD5();
		if (newFile.getName().endsWith("txt")
				|| newFile.getName().endsWith("TXT")|| newFile.getName().endsWith(".000")) {
			String md5str = filemd5.getMD5(newFile);
		}
		if (newFile.getName().endsWith("zip")) {
			if (ZipUtil.unzip(newFile, datapath)) {
				File file = new File(datapath);
				File[] filelist = file.listFiles();
				for (File fortmp : filelist) {
					if (fortmp.getName().endsWith(".000")) {
						filemd5.getMD5(fortmp);
					}
				}
			}
			newFile.delete();
		}
		System.out.println(newFile.getName());
		System.out.println(newFile.getAbsolutePath());
		//System.out.println(md5str);	
		System.out.println("OperationType is " + OperationType);
		parameterMap = new HashMap();
		parameterMap.put("audit_flag", OperationType);
		List<Map> resultType = EasyDataFatcherOnIbatis.queryBySqlKey(
				"checkFtpType", false, parameterMap);
		String host = (String) resultType.get(0).get("FTPHOST");
		String user = (String) resultType.get(0).get("PROGUSER");
		String pass = (String) resultType.get(0).get("PROGPASS");
		String path = (String) resultType.get(0).get("REMOTEDIRECTORY");
		//String relpath=path+rpmonth+"/";
		String relpath;
		relpath = path + rpmonth.substring(2, 6) + "/";
		if (OperationType==3||OperationType==4){
			relpath =new String(path);
		}
		System.out.println(host);
		System.out.println(user);
		System.out.println(pass);
		System.out.println(path);
		System.out.println(relpath);
		FtpBBSUtil.getFtpBBS().FtpSento(datapath, host, user, pass, relpath);
		getResponse().setContentType("text/html;charset=utf-8");
		getResponse().getWriter().write(
				"<script>alert('文件已经上传到指定的目录中了22223');</script>");
		getResponse().getWriter().flush();
		return SUCCESS;
	}

	public String getRpmonth() {
		return rpmonth;
	}

	public void setRpmonth(String rpmonth) {
		this.rpmonth = rpmonth;
	}

}
